package com.example.notes;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class NoteAdapter extends RecyclerView.Adapter<NoteViewHolder>{

    private final MainActivity mainAct;

    private ArrayList<Note> entries = new ArrayList<>();


    public NoteAdapter(ArrayList<Note> notes, MainActivity ma) {
        this.entries = notes;
        mainAct = ma;
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull final ViewGroup parent, int viewType) { //the adapter has to create multiple view items (e.g while you're scrolling up or when it is being displayed for the first time), this is what the function does
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.note_entry, parent, false); //inflate the layout and return the viewholder, pass in the layout name, the parent


        return new NoteViewHolder(itemView); //then we return an EmployeeViewHolder object and pass it in the inflater layout as well.

        //the whole gist of this func is to inflate the layout, build the view holder and return the view holder. It is automatically called
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position){

        Note n = entries.get(position);
        holder.title.setText(n.getTitle());
        holder.date.setText(String.valueOf(n.getDate()));
        holder.note.setText(n.getNote());

    }

    @Override
    public int getItemCount() {
        return entries.size();
    }

}
