package com.example.notes;
import androidx.annotation.NonNull;

import java.util.Date;

public class Note {

    private final String title;
    private final Date date;
    private final String note;

    private static int ctr = 1;

    Note(){
        this.title = "Title " + ctr;
        this.date = new Date();
        this.note = "Note " + ctr;
        ctr++;
    }

    public String getTitle(){return title;}

    Date getDate(){return date;}

    String getNote(){return note;}

    @NonNull
    @Override
    public String toString() {
        return title + " (" + date+ "), " + note;
    }
}
